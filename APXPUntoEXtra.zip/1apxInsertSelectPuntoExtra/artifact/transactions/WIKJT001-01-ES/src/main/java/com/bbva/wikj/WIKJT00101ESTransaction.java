package com.bbva.wikj;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * transaccion_customer
 *
 */
public class WIKJT00101ESTransaction extends AbstractWIKJT00101ESTransaction {

	private static final Logger LOGGER = LoggerFactory.getLogger(WIKJT00101ESTransaction.class);

	/**
	 * The execute method...
	 */
	@Override
	public void execute() {
		// TODO - Implementation of business logic

	}

}
