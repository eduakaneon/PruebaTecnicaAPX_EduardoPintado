package com.bbva.wikj.lib.r001;

/**
 * The  interface WIKJR001 class...
 */
public interface WIKJR001 {

	/**
	 * The execute method...
	 */
	void execute();

}
