package com.bbva.wikj.lib.r123.impl;

import com.bbva.wikj.dto.ejemploselect.CustomerIn;
import com.bbva.wikj.dto.ejemploselect.CustomerOut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * The WIKJR123Impl class...
 */
public class
WIKJR123Impl extends WIKJR123Abstract {

	private static final Logger LOGGER = LoggerFactory.getLogger(WIKJR123Impl.class);



	@Override
	public int executeInsert(CustomerIn customerIn) {
		Map<String, Object> args = new HashMap<>();
		args.put("id", customerIn.getId());
		args.put("fecha", customerIn.getFecha());
		return this.jdbcUtils.update("query.insert",args);

	}

	@Override
	public CustomerOut executeSelect(String fecha) {
		Map<String, Object> result = new HashMap<>();
		result = this.jdbcUtils.queryForMap("query.select",fecha);
		CustomerOut customerOut = new CustomerOut();

		customerOut.setFecha(String.valueOf(result.get("fecha")));
		customerOut.setId(String.valueOf(result.get("id")));


		return customerOut;
	}

}
