package com.bbva.wikj.dto.ejemploselect;

import java.io.Serializable;

/**
 * The ExampleDTO class...
 */
public class CustomerOut implements Serializable  {
	private String id;

	private String fecha;
	//private String customerId;

	public CustomerOut() {
	}
//	public String getCustomerId() {
//		return this.customerId;
//	}
//
//	public void setCustomerId(String customerId) {
//		this.customerId = customerId;
//	}
	public String getFecha() {return this.fecha; }

	public void setFecha(String fecha) {this.fecha = fecha; }

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}


}
