package com.bbva.wikj.dto.ejemploselect;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * The ExampleDTO class...
 */
public class CustomerIn implements Serializable  {
	private String id;
	//private String customerId;
	private String fecha;

	public CustomerIn() {
	}

//	public String getCustomerId() {
//		return this.customerId;
//	}
//
//	public void setCustomerId(String customerId) {
//		this.customerId = customerId;
//	}

	public String getFecha() {return this.fecha; }

	public void setFecha(String fecha) {this.fecha = fecha; }

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}


}
