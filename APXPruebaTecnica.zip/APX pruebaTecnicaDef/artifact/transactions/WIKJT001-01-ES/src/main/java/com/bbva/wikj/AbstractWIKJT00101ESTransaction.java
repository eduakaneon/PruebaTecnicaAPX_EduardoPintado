package com.bbva.wikj;

import com.bbva.elara.transaction.AbstractTransaction;

/**
 * In this class, the input and output data is defined automatically through the setters and getters.
 */
public abstract class AbstractWIKJT00101ESTransaction extends AbstractTransaction {

	public AbstractWIKJT00101ESTransaction(){
	}

}
