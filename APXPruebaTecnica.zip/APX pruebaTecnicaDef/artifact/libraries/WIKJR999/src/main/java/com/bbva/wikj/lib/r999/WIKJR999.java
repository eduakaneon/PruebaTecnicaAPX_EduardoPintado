package com.bbva.wikj.lib.r999;

import com.bbva.wikj.dto.ejemplo.DtoIn;
import com.bbva.wikj.dto.ejemplo.DtoOut;

/**
 * The  interface WIKJR999 class...
 */
public interface WIKJR999 {

	/**
	 * The execute method...
	 */
	DtoOut execute(DtoIn dtoIn);

}
